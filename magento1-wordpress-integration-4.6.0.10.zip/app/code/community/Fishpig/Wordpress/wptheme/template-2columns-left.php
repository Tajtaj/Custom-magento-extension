<?php
/**
 * Template Name: 2 Columns Left
 * Template Post Type: post, page
 */

get_template_part('index');
