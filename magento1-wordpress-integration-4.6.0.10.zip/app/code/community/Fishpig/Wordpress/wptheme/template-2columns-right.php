<?php
/**
 * Template Name: 2 Columns Right
 * Template Post Type: post, page
 */

get_template_part('index');
