<?php
/**
 * Please do not modify this file.
 * Any changes you make will be overwritten
 * This file is not used to display your blog.
 */

get_header(); ?>

<h1>404</h1>

<?php get_footer();
