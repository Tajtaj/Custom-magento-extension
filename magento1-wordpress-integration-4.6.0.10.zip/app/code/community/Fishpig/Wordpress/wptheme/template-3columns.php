<?php
/**
 * Template Name: 3 Columns
 * Template Post Type: post, page
 */

get_template_part('index');
