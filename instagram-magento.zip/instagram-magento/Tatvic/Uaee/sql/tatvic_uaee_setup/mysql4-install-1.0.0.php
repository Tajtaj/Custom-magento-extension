<?php
/**
 * @package 
 * @author dvs.spy (jigar@tatvic.com)
 * @license Tatvic Enhanced Ecommerce
 */ 

$installer = $this;

$installer->startSetup();



$installer->endSetup();